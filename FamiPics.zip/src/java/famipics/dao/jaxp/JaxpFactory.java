/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package famipics.dao.jaxp;

/**
 *
 * @author guillermo
 */
final class JaxpFactory {
    static final String repositoryPath = "/home/guillermo/Documents/Academico/UBB/MCC 2014/1. Primer Semestre/TO/Talleres/Taller 2/WebApp/FamiPics/database/famipics-repo.xml";
}
